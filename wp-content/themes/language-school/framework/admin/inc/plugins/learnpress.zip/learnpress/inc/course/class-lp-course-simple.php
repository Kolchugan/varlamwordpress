<?php

defined( 'ABSPATH' ) || exit();

/**
 * Class LP_Course_Simple
 */
class LP_Course_Simple extends LP_Course{

}