<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */
defined('ABSPATH') || exit();
?>
<div class="course-introduce">

	<?php the_excerpt();?>

</div>
