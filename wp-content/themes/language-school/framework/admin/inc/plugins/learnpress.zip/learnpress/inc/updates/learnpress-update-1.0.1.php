<?php

update_option( 'learn_press_current_version_101', '1.0.1' );