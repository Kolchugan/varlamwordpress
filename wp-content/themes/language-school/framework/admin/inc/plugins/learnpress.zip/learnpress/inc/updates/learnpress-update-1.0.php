<?php

update_option( 'learn_press_current_version_10', '1.0' );