</div>
</div>
<script type="text/javascript">
	jQuery(function ($) {
		LearnPress.sortableQuestionAnswers($('#learn-press-question-<?php echo $this->id;?>'));
	})
</script>