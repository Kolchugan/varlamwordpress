<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */

defined( 'ABSPATH' ) || exit();
?>
<script type="text/javascript">
	jQuery(function(){
		<?php echo $code;?>
	});
</script>
